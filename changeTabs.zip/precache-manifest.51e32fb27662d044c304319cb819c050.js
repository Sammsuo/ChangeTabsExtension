self.__precacheManifest = [
  {
    "revision": "abd13c960a5a0e3953dc",
    "url": "/js/about.cefc2321.js"
  },
  {
    "revision": "47e23e646758c098fc2f",
    "url": "/css/app.72a73660.css"
  },
  {
    "revision": "47e23e646758c098fc2f",
    "url": "/js/app.8f5a71b7.js"
  },
  {
    "revision": "d3f8a57557b96225a269",
    "url": "/css/chunk-vendors.81da9e9e.css"
  },
  {
    "revision": "d3f8a57557b96225a269",
    "url": "/js/chunk-vendors.d9dba2e9.js"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "82b9c7a5a3f405032b1db71a25f67021",
    "url": "/img/logo.82b9c7a5.png"
  },
  {
    "revision": "ab356419482e772da78b23aaac23c8ac",
    "url": "/index.html"
  },
  {
    "revision": "3887a2de0a1fe1cfb18191c387febec4",
    "url": "/background.js"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "d6f659d33566aed5f4a08c63c9acb148",
    "url": "/img/userHead.png"
  }
];